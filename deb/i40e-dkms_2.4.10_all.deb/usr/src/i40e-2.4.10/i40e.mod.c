#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x533a1566, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x30016bdf, __VMLINUX_SYMBOL_STR(netdev_info) },
	{ 0x8733c9e1, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0x274c0fad, __VMLINUX_SYMBOL_STR(pci_bus_read_config_byte) },
	{ 0xd2b09ce5, __VMLINUX_SYMBOL_STR(__kmalloc) },
	{ 0xd19cecc9, __VMLINUX_SYMBOL_STR(perf_tp_event) },
	{ 0xcbefa9db, __VMLINUX_SYMBOL_STR(ethtool_op_get_ts_info) },
	{ 0xf9a482f9, __VMLINUX_SYMBOL_STR(msleep) },
	{ 0x8e2d83b6, __VMLINUX_SYMBOL_STR(node_to_cpumask_map) },
	{ 0xd4cddbbd, __VMLINUX_SYMBOL_STR(dcb_ieee_setapp) },
	{ 0x579d8203, __VMLINUX_SYMBOL_STR(pci_enable_sriov) },
	{ 0x60209fa4, __VMLINUX_SYMBOL_STR(debugfs_create_dir) },
	{ 0x349cba85, __VMLINUX_SYMBOL_STR(strchr) },
	{ 0xb6b46a7c, __VMLINUX_SYMBOL_STR(param_ops_int) },
	{ 0x91eb9b4, __VMLINUX_SYMBOL_STR(round_jiffies) },
	{ 0xa90a97d8, __VMLINUX_SYMBOL_STR(dcb_ieee_delapp) },
	{ 0x754d539c, __VMLINUX_SYMBOL_STR(strlen) },
	{ 0x49ed58da, __VMLINUX_SYMBOL_STR(qdisc_reset) },
	{ 0xbe2701fd, __VMLINUX_SYMBOL_STR(skb_pad) },
	{ 0x43a53735, __VMLINUX_SYMBOL_STR(__alloc_workqueue_key) },
	{ 0x9469482, __VMLINUX_SYMBOL_STR(kfree_call_rcu) },
	{ 0xc4f331c6, __VMLINUX_SYMBOL_STR(cpu_online_mask) },
	{ 0x79aa04a2, __VMLINUX_SYMBOL_STR(get_random_bytes) },
	{ 0xdffed6b1, __VMLINUX_SYMBOL_STR(dma_set_mask) },
	{ 0x55f38421, __VMLINUX_SYMBOL_STR(node_data) },
	{ 0xfef7b4b8, __VMLINUX_SYMBOL_STR(dev_mc_add_excl) },
	{ 0xccc310c7, __VMLINUX_SYMBOL_STR(napi_complete) },
	{ 0x8676fbf4, __VMLINUX_SYMBOL_STR(pci_disable_device) },
	{ 0x764f2f74, __VMLINUX_SYMBOL_STR(dev_uc_add_excl) },
	{ 0xc7a4fbed, __VMLINUX_SYMBOL_STR(rtnl_lock) },
	{ 0x11c388b6, __VMLINUX_SYMBOL_STR(pci_disable_msix) },
	{ 0x4ea25709, __VMLINUX_SYMBOL_STR(dql_reset) },
	{ 0x6c49b1e2, __VMLINUX_SYMBOL_STR(netif_carrier_on) },
	{ 0x1637ff0f, __VMLINUX_SYMBOL_STR(_raw_spin_lock_bh) },
	{ 0x45560141, __VMLINUX_SYMBOL_STR(pci_disable_sriov) },
	{ 0xadd57313, __VMLINUX_SYMBOL_STR(__hw_addr_sync_dev) },
	{ 0x5c5d54f4, __VMLINUX_SYMBOL_STR(skb_clone) },
	{ 0xc0a3d105, __VMLINUX_SYMBOL_STR(find_next_bit) },
	{ 0x52a7fc2f, __VMLINUX_SYMBOL_STR(netif_carrier_off) },
	{ 0x88bfa7e, __VMLINUX_SYMBOL_STR(cancel_work_sync) },
	{ 0xf087137d, __VMLINUX_SYMBOL_STR(__dynamic_pr_debug) },
	{ 0xba29689c, __VMLINUX_SYMBOL_STR(x86_dma_fallback_dev) },
	{ 0x2763f67c, __VMLINUX_SYMBOL_STR(__dev_kfree_skb_any) },
	{ 0xeae3dfd6, __VMLINUX_SYMBOL_STR(__const_udelay) },
	{ 0x593a99b, __VMLINUX_SYMBOL_STR(init_timer_key) },
	{ 0x7e149286, __VMLINUX_SYMBOL_STR(mutex_unlock) },
	{ 0x2447533c, __VMLINUX_SYMBOL_STR(ktime_get_real) },
	{ 0xa9348cf6, __VMLINUX_SYMBOL_STR(debugfs_create_file) },
	{ 0x4629334c, __VMLINUX_SYMBOL_STR(__preempt_count) },
	{ 0x7a2af7b4, __VMLINUX_SYMBOL_STR(cpu_number) },
	{ 0xd32be537, __VMLINUX_SYMBOL_STR(ipv6_find_hdr) },
	{ 0x4aee9474, __VMLINUX_SYMBOL_STR(debugfs_remove_recursive) },
	{ 0xf4c91ed, __VMLINUX_SYMBOL_STR(ns_to_timespec) },
	{ 0x82c7831a, __VMLINUX_SYMBOL_STR(__alloc_pages_nodemask) },
	{ 0x92dcc4e1, __VMLINUX_SYMBOL_STR(netif_napi_del) },
	{ 0x4c7e23cf, __VMLINUX_SYMBOL_STR(sock_queue_err_skb) },
	{ 0x7d11c268, __VMLINUX_SYMBOL_STR(jiffies) },
	{ 0xeecd85d7, __VMLINUX_SYMBOL_STR(__dynamic_netdev_dbg) },
	{ 0x3ab2e538, __VMLINUX_SYMBOL_STR(__netdev_alloc_skb) },
	{ 0x9cce39f7, __VMLINUX_SYMBOL_STR(__pskb_pull_tail) },
	{ 0xc2ed4efd, __VMLINUX_SYMBOL_STR(ptp_clock_unregister) },
	{ 0xc671e369, __VMLINUX_SYMBOL_STR(_copy_to_user) },
	{ 0xfe7c4287, __VMLINUX_SYMBOL_STR(nr_cpu_ids) },
	{ 0x749dcc9f, __VMLINUX_SYMBOL_STR(pci_set_master) },
	{ 0xd5f2172f, __VMLINUX_SYMBOL_STR(del_timer_sync) },
	{ 0x5b25284, __VMLINUX_SYMBOL_STR(trace_define_field) },
	{ 0x201cf252, __VMLINUX_SYMBOL_STR(ftrace_event_buffer_commit) },
	{ 0xfb578fc5, __VMLINUX_SYMBOL_STR(memset) },
	{ 0xb0a2cf98, __VMLINUX_SYMBOL_STR(pci_enable_pcie_error_reporting) },
	{ 0xddeff2e, __VMLINUX_SYMBOL_STR(pci_restore_state) },
	{ 0x3a401b73, __VMLINUX_SYMBOL_STR(dev_err) },
	{ 0x2e51823, __VMLINUX_SYMBOL_STR(__mutex_init) },
	{ 0x5c4b4af2, __VMLINUX_SYMBOL_STR(netif_set_xps_queue) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0xb1d7dca1, __VMLINUX_SYMBOL_STR(ethtool_op_get_link) },
	{ 0x20c55ae0, __VMLINUX_SYMBOL_STR(sscanf) },
	{ 0x3c3fce39, __VMLINUX_SYMBOL_STR(__local_bh_enable_ip) },
	{ 0x449ad0a7, __VMLINUX_SYMBOL_STR(memcmp) },
	{ 0xa00aca2a, __VMLINUX_SYMBOL_STR(dql_completed) },
	{ 0x4c9d28b0, __VMLINUX_SYMBOL_STR(phys_base) },
	{ 0xcd279169, __VMLINUX_SYMBOL_STR(nla_find) },
	{ 0xc08b27b2, __VMLINUX_SYMBOL_STR(vxlan_get_rx_port) },
	{ 0xe31d7ebd, __VMLINUX_SYMBOL_STR(free_netdev) },
	{ 0xa1c76e0a, __VMLINUX_SYMBOL_STR(_cond_resched) },
	{ 0x9166fada, __VMLINUX_SYMBOL_STR(strncpy) },
	{ 0x5338dabf, __VMLINUX_SYMBOL_STR(register_netdev) },
	{ 0x90e8802f, __VMLINUX_SYMBOL_STR(dcbnl_ieee_notify) },
	{ 0x5a921311, __VMLINUX_SYMBOL_STR(strncmp) },
	{ 0x5792f848, __VMLINUX_SYMBOL_STR(strlcpy) },
	{ 0x16305289, __VMLINUX_SYMBOL_STR(warn_slowpath_null) },
	{ 0xbe2bdb48, __VMLINUX_SYMBOL_STR(mutex_lock) },
	{ 0x8c03d20c, __VMLINUX_SYMBOL_STR(destroy_workqueue) },
	{ 0x23c61e3c, __VMLINUX_SYMBOL_STR(sk_free) },
	{ 0x5839d533, __VMLINUX_SYMBOL_STR(netif_set_real_num_rx_queues) },
	{ 0xf4f14de6, __VMLINUX_SYMBOL_STR(rtnl_trylock) },
	{ 0x8834396c, __VMLINUX_SYMBOL_STR(mod_timer) },
	{ 0xd3646390, __VMLINUX_SYMBOL_STR(netif_set_real_num_tx_queues) },
	{ 0x7f69de11, __VMLINUX_SYMBOL_STR(netif_napi_add) },
	{ 0x9fc07f13, __VMLINUX_SYMBOL_STR(ptp_clock_register) },
	{ 0xd6b8e852, __VMLINUX_SYMBOL_STR(request_threaded_irq) },
	{ 0x55181725, __VMLINUX_SYMBOL_STR(cpu_bit_bitmap) },
	{ 0x91588663, __VMLINUX_SYMBOL_STR(simple_open) },
	{ 0x1c3bbb0d, __VMLINUX_SYMBOL_STR(__get_page_tail) },
	{ 0x9f46ced8, __VMLINUX_SYMBOL_STR(__sw_hweight64) },
	{ 0xe523ad75, __VMLINUX_SYMBOL_STR(synchronize_irq) },
	{ 0x4ed3ccc8, __VMLINUX_SYMBOL_STR(ftrace_event_reg) },
	{ 0x167c5967, __VMLINUX_SYMBOL_STR(print_hex_dump) },
	{ 0x9dacaa1c, __VMLINUX_SYMBOL_STR(pci_select_bars) },
	{ 0xae65ba7f, __VMLINUX_SYMBOL_STR(napi_gro_receive) },
	{ 0xef3867d, __VMLINUX_SYMBOL_STR(_dev_info) },
	{ 0xb77d6633, __VMLINUX_SYMBOL_STR(__hw_addr_unsync_dev) },
	{ 0x78764f4e, __VMLINUX_SYMBOL_STR(pv_irq_ops) },
	{ 0xc6fdaa32, __VMLINUX_SYMBOL_STR(__free_pages) },
	{ 0x618911fc, __VMLINUX_SYMBOL_STR(numa_node) },
	{ 0x42c8de35, __VMLINUX_SYMBOL_STR(ioremap_nocache) },
	{ 0x12a38747, __VMLINUX_SYMBOL_STR(usleep_range) },
	{ 0xb0bd4206, __VMLINUX_SYMBOL_STR(pci_enable_msix_range) },
	{ 0xc6559d8f, __VMLINUX_SYMBOL_STR(ipv6_skip_exthdr) },
	{ 0x78c58288, __VMLINUX_SYMBOL_STR(__napi_schedule) },
	{ 0xba63339c, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_bh) },
	{ 0xd160805c, __VMLINUX_SYMBOL_STR(pci_cleanup_aer_uncorrect_error_status) },
	{ 0xdb7305a1, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0xb152d87d, __VMLINUX_SYMBOL_STR(cpu_possible_mask) },
	{ 0x74ff6593, __VMLINUX_SYMBOL_STR(skb_checksum_help) },
	{ 0xaa0073b7, __VMLINUX_SYMBOL_STR(__net_get_random_once) },
	{ 0x179610f4, __VMLINUX_SYMBOL_STR(kfree_skb) },
	{ 0xc4d760c7, __VMLINUX_SYMBOL_STR(irq_set_affinity_notifier) },
	{ 0x6bb041c0, __VMLINUX_SYMBOL_STR(eth_type_trans) },
	{ 0x4234f096, __VMLINUX_SYMBOL_STR(cpumask_next_and) },
	{ 0x419cf0d2, __VMLINUX_SYMBOL_STR(dev_driver_string) },
	{ 0x39e141bc, __VMLINUX_SYMBOL_STR(pskb_expand_head) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
	{ 0x91e09a0c, __VMLINUX_SYMBOL_STR(netdev_err) },
	{ 0xa90dda32, __VMLINUX_SYMBOL_STR(pci_enable_msi_range) },
	{ 0xab905eb7, __VMLINUX_SYMBOL_STR(pci_unregister_driver) },
	{ 0xcc5005fe, __VMLINUX_SYMBOL_STR(msleep_interruptible) },
	{ 0x20705009, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0xd52bf1ce, __VMLINUX_SYMBOL_STR(_raw_spin_lock) },
	{ 0xe4982bef, __VMLINUX_SYMBOL_STR(__dynamic_dev_dbg) },
	{ 0x220babbb, __VMLINUX_SYMBOL_STR(ftrace_event_buffer_reserve) },
	{ 0x4648b3bf, __VMLINUX_SYMBOL_STR(event_triggers_call) },
	{ 0xc8b6a128, __VMLINUX_SYMBOL_STR(pci_set_power_state) },
	{ 0x37b89fea, __VMLINUX_SYMBOL_STR(netdev_warn) },
	{ 0xa4dcdbf3, __VMLINUX_SYMBOL_STR(eth_validate_addr) },
	{ 0x1e047854, __VMLINUX_SYMBOL_STR(warn_slowpath_fmt) },
	{ 0x1db62725, __VMLINUX_SYMBOL_STR(pci_disable_pcie_error_reporting) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x69acdf38, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0x2a042acf, __VMLINUX_SYMBOL_STR(trace_event_raw_init) },
	{ 0xc4122d75, __VMLINUX_SYMBOL_STR(ptp_clock_index) },
	{ 0xbe8fd918, __VMLINUX_SYMBOL_STR(pci_disable_msi) },
	{ 0xd0544ba0, __VMLINUX_SYMBOL_STR(dma_supported) },
	{ 0xc31a17d1, __VMLINUX_SYMBOL_STR(skb_add_rx_frag) },
	{ 0x93cbae80, __VMLINUX_SYMBOL_STR(pci_num_vf) },
	{ 0xedc03953, __VMLINUX_SYMBOL_STR(iounmap) },
	{ 0x42bb8d80, __VMLINUX_SYMBOL_STR(perf_trace_buf_prepare) },
	{ 0xe729a53d, __VMLINUX_SYMBOL_STR(__pci_register_driver) },
	{ 0xa8721b97, __VMLINUX_SYMBOL_STR(system_state) },
	{ 0x7628f3c7, __VMLINUX_SYMBOL_STR(this_cpu_off) },
	{ 0xb352177e, __VMLINUX_SYMBOL_STR(find_first_bit) },
	{ 0x4cbbd171, __VMLINUX_SYMBOL_STR(__bitmap_weight) },
	{ 0xebad2285, __VMLINUX_SYMBOL_STR(dev_warn) },
	{ 0x72b637fe, __VMLINUX_SYMBOL_STR(unregister_netdev) },
	{ 0x39bd74a3, __VMLINUX_SYMBOL_STR(ndo_dflt_bridge_getlink) },
	{ 0x2e0d2f7f, __VMLINUX_SYMBOL_STR(queue_work_on) },
	{ 0x1df99213, __VMLINUX_SYMBOL_STR(pci_vfs_assigned) },
	{ 0x28318305, __VMLINUX_SYMBOL_STR(snprintf) },
	{ 0xddcdd00b, __VMLINUX_SYMBOL_STR(__netif_schedule) },
	{ 0x1e3a88fb, __VMLINUX_SYMBOL_STR(trace_seq_printf) },
	{ 0x5411451c, __VMLINUX_SYMBOL_STR(consume_skb) },
	{ 0x41a0b885, __VMLINUX_SYMBOL_STR(pci_enable_device_mem) },
	{ 0x7e6cd403, __VMLINUX_SYMBOL_STR(skb_tstamp_tx) },
	{ 0x30ef8422, __VMLINUX_SYMBOL_STR(pci_wake_from_d3) },
	{ 0xf7878e93, __VMLINUX_SYMBOL_STR(pci_release_selected_regions) },
	{ 0x1fae6766, __VMLINUX_SYMBOL_STR(pci_request_selected_regions) },
	{ 0xca7903a1, __VMLINUX_SYMBOL_STR(irq_set_affinity_hint) },
	{ 0xb5419b40, __VMLINUX_SYMBOL_STR(_copy_from_user) },
	{ 0x1f51bf7b, __VMLINUX_SYMBOL_STR(skb_copy_bits) },
	{ 0x190dd5be, __VMLINUX_SYMBOL_STR(ftrace_raw_output_prep) },
	{ 0x6e720ff2, __VMLINUX_SYMBOL_STR(rtnl_unlock) },
	{ 0x3c818ea2, __VMLINUX_SYMBOL_STR(dma_ops) },
	{ 0x75861c57, __VMLINUX_SYMBOL_STR(device_set_wakeup_enable) },
	{ 0xc0eda853, __VMLINUX_SYMBOL_STR(pcie_capability_read_word) },
	{ 0xf20dabd8, __VMLINUX_SYMBOL_STR(free_irq) },
	{ 0xac9fda92, __VMLINUX_SYMBOL_STR(pci_save_state) },
	{ 0xe914e41e, __VMLINUX_SYMBOL_STR(strcpy) },
	{ 0x821c9ff7, __VMLINUX_SYMBOL_STR(alloc_etherdev_mqs) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=ptp,vxlan";

MODULE_ALIAS("pci:v00008086d00001572sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001574sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001580sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001581sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001583sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001584sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001585sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001586sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001589sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001587sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d00001588sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000037CEsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000037CFsv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000037D0sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000037D1sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000037D2sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d000037D3sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000158Asv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v00008086d0000158Bsv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "3977C21019A3C4865FF253A");
